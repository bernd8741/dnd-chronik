# DIE CHRONIK DER VIER GEFÄHRTEN

Eine vollständig statische Fantasy-Website für euer fortlaufendes D&D-Abenteuertagebuch.

## 1. Sofort ansehen

1. Entpacke `DND_Chronik_Website.zip` in einen Ordner.
2. Öffne `index.html` per Doppelklick mit Chrome, Firefox oder Edge.
3. Die Website funktioniert auch ohne Internet. Wenn Google Fonts nicht geladen werden, benutzt sie lokale Ersatzschriften.

**Inhalt des Entwurfs:**
- Startseite mit eurer bereits generierten Tavernenszene.
- Öffnende Charakterkarten für Murtagh, Gamakichi, Heela und Asphodel.
- Bildreferenzen für Murtagh und Gamakichi.
- Platzhalter für Heela und Asphodel, bis die Referenzbilder vorliegen.
- Zwei Chronik-Einträge: öffentlicher Prolog und *ausdrücklich als Entwurf* markierte Tavernenszene.
- Eine automatisch aus den Kapiteln erstellte Zeitleiste.
- Kapitelwechsel, Bildvergrößerung und mobile Ansicht.
- Eine eigene Datei `content.js`, in der alle Texte und Kapitel gesammelt sind.

**Wichtig:** Die Tavernenszene ist ein *Beispielentwurf* und noch keine festgeschriebene Session. Datumsangaben fehlen absichtlich, solange keine tatsächlichen Spieltermine bekannt sind. Geheime Informationen zu Murtagh und P-Nut sind nicht enthalten. Die kurzen Charakter-Leitsprüche in der Galerie sind atmosphärische **Beispieltexte**, keine bestätigten Zitate aus eurer Kampagne.

## 2. Unter einem DAUERHAFTEN Link veröffentlichen (GitHub Pages)

Diese Variante kostet bei Nutzung eines **öffentlichen Repositorys** mit GitHub Free nichts. Die Website ist dann öffentlich abrufbar. Du brauchst nur einen GitHub-Account.

1. Öffne https://github.com/ und registriere dich bzw. melde dich an.
2. Klicke rechts oben auf das **+** und wähle **New repository**.
3. Repository-Name z.B. `dnd-chronik` (kleingeschrieben, ohne Leerzeichen). Wähle **Public** und erstelle das Repository.
4. Öffne das neue Repository. Klicke **Add file > Upload files**. Lade **den Inhalt des entpackten Website-Ordners** hoch: `index.html`, `styles.css`, `app.js`, `content.js`, den ganzen Ordner `assets/` und optional `README_START_HIER.md`. Achte darauf, dass `index.html` direkt im Hauptverzeichnis des Repositorys liegt (nicht in einem Unterordner `dnd_chronik_site`).
5. Bestätige mit **Commit changes**.
6. Öffne **Settings > Pages**.
7. Unter **Build and deployment** bei **Source**: `Deploy from a branch`.
8. Bei **Branch** `main` und `/(root)` wählen, dann **Save**.
9. Die Website ist anschließend unter diesem festen Link erreichbar:

   `https://DEIN-GITHUB-NAME.github.io/dnd-chronik/`

Ersetze `DEIN-GITHUB-NAME` durch deinen eigenen GitHub-Benutzernamen. Die Adresse bleibt gleich, wenn du weitere Kapitel hinzufügst. Der Link ist erst nach deinem tatsächlichen Upload und der Veröffentlichung erreichbar.

Dokumentation: https://docs.github.com/de/pages/getting-started-with-github-pages/creating-a-github-pages-site

**Achtung:** GitHub Pages ist kein privates, passwortgeschütztes Tagebuch. Alle Seiten, Texte und Bilder im veröffentlichten Projekt sind grundsätzlich öffentlich erreichbar. Schreibe keine Geheimnisse, persönlichen Daten oder Spoiler hinein, die die Gruppe nicht sehen soll.

## 3. Ein neues Kapitel hinzufügen

Alle Texte, Charaktere und Kapitel stehen **nur in `content.js`**. Du brauchst in `index.html` nichts umzubauen. Im Abschnitt `chapters: [ ... ]` kannst du das letzte Kapitel kopieren und direkt danach ein weiteres einfügen.

Beispiel für ein neues Kapitel innerhalb des `chapters`-Arrays:

```javascript
{
  id: "kapitel-02",                        // eindeutig, ohne Leerzeichen
  label: "Kapitel II",                     // Beschriftung
  title: "Das Rätsel am alten Weg",        // Kapitelüberschrift
  subtitle: "Eine neue Spur führt in die Berge.",
  date: "2026-11-12",                      // echtes Sessiondatum: YYYY-MM-DD oder null
  time: "19:30",                          // optional: Uhrzeit, sonst null
  dateLabel: "12. November 2026",         // wird nur verwendet, wenn date null ist
  session: "Session 2",
  inWorldDate: "3. Tag des Nebelmonds",  // falls Spielweltdatum bekannt; sonst "Noch offen"
  location: "Alter Gebirgspass",
  image: "assets/kapitel-02.webp",        // Bilddatei muss im assets-Ordner liegen
  imageAlt: "Die Gefährten vor einem alten Gebirgspass",
  state: "story",                         // oder "draft" für Entwurf
  summary: "Die Gefährten entdecken eine seltsame Spur.",
  paragraphs: [
    "Erster Absatz über das, was wirklich passiert ist.",
    "Zweiter Absatz. Du kannst beliebig viele Absätze angeben."
  ]
},
```

Denke an ein **Komma** zwischen benachbarten `{ ... }`-Einträgen. Datumsangaben sind nur Beispiele. Nutze für reale Sessiondaten eure tatsächlichen Spieltermine.

Nach dem Speichern werden Kapitelmenü, Leser, Kapitelanzahl und Zeitleiste **automatisch** aktualisiert. Jedes Kapitel lässt sich auch direkt mit `#kapitel-02` verlinken, z.B. `https://DEIN-GITHUB-NAME.github.io/dnd-chronik/#kapitel-02`.

### Nach einer neuen Session (am einfachsten mit ChatGPT)

Du kannst mir einfach schreiben:

> "Erweitere unser D&D-Tagebuch um Kapitel 2. Das ist passiert: [Stichworte]. Nutze die gleiche HTML-Website. Ein Sessionbild ist angehängt. Keine Geheimnisse veröffentlichen."

Dann kann ich dir eine aktualisierte Version mit fertigem Kapitel und Bilddateien erstellen. Zum Veröffentlichen musst du die geänderten Dateien auf GitHub hochladen oder eine geeignete GitHub-Verbindung freigeben.

### Bestehende Website auf GitHub aktualisieren

- Für reinen Text oder ein neues Kapitel: auf GitHub `content.js` öffnen, mit dem **Stiftsymbol** bearbeiten und **Commit changes** wählen; die Seite wird danach mit demselben Link neu bereitgestellt.
- Für neue Bilder: im Repository `assets/` öffnen und das Bild per **Add file > Upload files** hochladen. In `content.js` den entsprechenden `image`-Pfad eintragen.
- Für eine komplett überarbeitete Version: die geänderten Dateien hochladen und alte Dateien bei Bedarf ersetzen. Nicht den Repository-Namen wechseln, dann bleibt der Link stabil.
- Eine Änderung wird nicht automatisch aus einem Chat in GitHub übertragen; sie muss veröffentlicht werden.

## 4. Charakterbilder austauschen

Für Heela und Asphodel kannst du beliebige eigene Referenzbilder im `assets/`-Ordner ablegen, etwa:

- `assets/heela.webp`
- `assets/asphodel.webp`

In `content.js` bei den jeweiligen Charakteren `image: ""` ändern zu `image: "assets/heela.webp"` beziehungsweise `image: "assets/asphodel.webp"`, und `status: "pending"` zu `status: "portrait"`.

Die Galerie übernimmt die neuen Bilder automatisch. **Empfehlung:** Porträtbilder etwa 760 × 970 Pixel, JPG oder WebP, möglichst unter 500 KB.

## 5. Zeitstempel und öffentliche/verborgene Informationen

- `date`: reales Kalenderdatum der Session, z.B. `"2026-11-12"`. Die Website formatiert es automatisch auf Deutsch.
- `time`: optionale reale Uhrzeit der Session, z.B. `"19:30"` (24-Stunden-Format). Wird neben dem Datum angezeigt.
- `session`: Sessionnummer, z.B. `"Session 3"`.
- `inWorldDate`: Datum im Spiel (aktuell im Datenmodell hinterlegt; kann später zusätzlich im sichtbaren Kapitelbereich angezeigt werden).
- `date: null`: unbekanntes Datum. Dann wird `dateLabel` statt eines erfundenen Datums angezeigt.
- `state: "draft"`: Kapitel erscheint mit einem sichtbaren Hinweis, dass die Handlung noch ein Entwurf ist.
- `state: "story"`: fertig ausgearbeitetes Kapitel.

**Datenschutz / Spoiler:** Geheime Plotinformationen niemals in `content.js` aufnehmen, wenn die Website öffentlich ist. Auch ausgeblendeter HTML-Text ist technisch lesbar. Halte geheime Aufzeichnungen lokal oder in einem getrennten, nicht veröffentlichten Dokument.

## 6. Filestruktur

```text
dnd-chronik/
├── index.html                  Hauptseite
├── styles.css                  Fantasy-Design / Mobile-Ansicht
├── app.js                      Kapitelwechsel, Galerie, Timeline
├── content.js                  DEINE GESCHICHTE (hier erweitern)
├── README_START_HIER.md        Diese Anleitung
└── assets/
    ├── favicon.svg
    ├── tavern.webp              Begegnung in der Taverne
    ├── forest-hut.webp          Murtaghs Waldhütte
    ├── murtagh.webp             Murtaghs Referenzporträt
    └── gamakichi.webp           Gamakichis Referenzporträt
```

Die Site benötigt keine Datenbank, keine Anmeldung für Leser, kein kostenpflichtiges Hosting und keinen Build-Schritt. Sie funktioniert als statische HTML-Seite mit JavaScript.
